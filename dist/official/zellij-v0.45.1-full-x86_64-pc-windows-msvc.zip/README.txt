Zellij offline portable package

Version: v0.45.1
Variant: full
Target: windows-x86_64

Run ./zellij.exe from this directory.
This package is self-contained and does not download anything at runtime.
Yazi, shells, SSH and Windows Terminal are packaged separately.
